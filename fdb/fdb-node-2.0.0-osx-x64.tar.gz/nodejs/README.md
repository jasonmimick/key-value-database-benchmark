Complete documentation of the FoundationDB Node.js API can be found at [https://foundationdb.com/documentation/latest/api-node.html](https://foundationdb.com/documentation/latest/api-node.html).

These bindings require the FoundationDB client, which is under a different license. The client can be obtained from [https://foundationdb.com/get](https://foundationdb.com/get).